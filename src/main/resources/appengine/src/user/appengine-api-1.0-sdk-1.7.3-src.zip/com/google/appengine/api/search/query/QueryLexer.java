

  package com.google.appengine.api.search.query;

import org.antlr.runtime.*;

public class QueryLexer extends Lexer {
    public static final int FUNCTION=7;
    public static final int LT=17;
    public static final int EXPONENT=40;
    public static final int FIX=30;
    public static final int GEO_POINT_FN=29;
    public static final int ESC=34;
    public static final int OCTAL_ESC=36;
    public static final int FUZZY=8;
    public static final int NOT=27;
    public static final int DISTANCE_FN=28;
    public static final int AND=25;
    public static final int ESCAPED_CHAR=42;
    public static final int EOF=-1;
    public static final int LPAREN=23;
    public static final int HAS=22;
    public static final int QUOTE=33;
    public static final int RPAREN=24;
    public static final int CHAR_SEQ=37;
    public static final int START_CHAR=41;
    public static final int ARGS=4;
    public static final int DIGIT=39;
    public static final int EQ=21;
    public static final int NE=20;
    public static final int GE=18;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__45=45;
    public static final int CONJUNCTION=5;
    public static final int UNICODE_ESC=35;
    public static final int NUMBER=38;
    public static final int HEX_DIGIT=44;
    public static final int LITERAL=10;
    public static final int VALUE=14;
    public static final int TEXT=32;
    public static final int REWRITE=31;
    public static final int SEQUENCE=13;
    public static final int DISJUNCTION=6;
    public static final int WS=15;
    public static final int NEGATION=11;
    public static final int OR=26;
    public static final int GT=19;
    public static final int GLOBAL=9;
    public static final int LE=16;
    public static final int MID_CHAR=43;
    public static final int STRING=12;

    public QueryLexer() {;}
    public QueryLexer(CharStream input) {
        this(input, new RecognizerSharedState());
    }
    public QueryLexer(CharStream input, RecognizerSharedState state) {
        super(input,state);

    }
    public String getGrammarFileName() { return "java/com/google/appengine/api/search/query/Query.g"; }

    public final void mT__45() throws RecognitionException {
        try {
            int _type = T__45;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match('-');

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mT__46() throws RecognitionException {
        try {
            int _type = T__46;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match(',');

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mT__47() throws RecognitionException {
        try {
            int _type = T__47;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match('\\');

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mHAS() throws RecognitionException {
        try {
            int _type = HAS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match(':');

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mOR() throws RecognitionException {
        try {
            int _type = OR;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match("OR");

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mAND() throws RecognitionException {
        try {
            int _type = AND;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match("AND");

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mNOT() throws RecognitionException {
        try {
            int _type = NOT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match("NOT");

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mREWRITE() throws RecognitionException {
        try {
            int _type = REWRITE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match('~');

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mFIX() throws RecognitionException {
        try {
            int _type = FIX;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match('+');

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mDISTANCE_FN() throws RecognitionException {
        try {
            int _type = DISTANCE_FN;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match("distance");

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mGEO_POINT_FN() throws RecognitionException {
        try {
            int _type = GEO_POINT_FN;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match("geopoint");

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mESC() throws RecognitionException {
        try {
            int _type = ESC;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            int alt1=3;
            int LA1_0 = input.LA(1);

            if ( (LA1_0=='\\') ) {
                switch ( input.LA(2) ) {
                case '\"':
                case '\\':
                    {
                    alt1=1;
                    }
                    break;
                case 'u':
                    {
                    alt1=2;
                    }
                    break;
                case '0':
                case '1':
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                    {
                    alt1=3;
                    }
                    break;
                default:
                    NoViableAltException nvae =
                        new NoViableAltException("", 1, 1, input);

                    throw nvae;
                }

            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }
            switch (alt1) {
                case 1 :
                    {
                    match('\\');
                    if ( input.LA(1)=='\"'||input.LA(1)=='\\' ) {
                        input.consume();

                    }
                    else {
                        MismatchedSetException mse = new MismatchedSetException(null,input);
                        recover(mse);
                        throw mse;}

                    }
                    break;
                case 2 :
                    {
                    mUNICODE_ESC();

                    }
                    break;
                case 3 :
                    {
                    mOCTAL_ESC();

                    }
                    break;

            }
            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mWS() throws RecognitionException {
        try {
            int _type = WS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            if ( (input.LA(1)>='\t' && input.LA(1)<='\n')||(input.LA(1)>='\f' && input.LA(1)<='\r')||input.LA(1)==' ' ) {
                input.consume();

            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mLPAREN() throws RecognitionException {
        try {
            int _type = LPAREN;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match('(');

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mRPAREN() throws RecognitionException {
        try {
            int _type = RPAREN;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match(')');

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mLT() throws RecognitionException {
        try {
            int _type = LT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match('<');

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mGT() throws RecognitionException {
        try {
            int _type = GT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match('>');

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mGE() throws RecognitionException {
        try {
            int _type = GE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match(">=");

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mLE() throws RecognitionException {
        try {
            int _type = LE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match("<=");

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mNE() throws RecognitionException {
        try {
            int _type = NE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match("!=");

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mEQ() throws RecognitionException {
        try {
            int _type = EQ;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match('=');

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mQUOTE() throws RecognitionException {
        try {
            int _type = QUOTE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match('\"');

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mTEXT() throws RecognitionException {
        try {
            int _type = TEXT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0=='!'||(LA6_0>='#' && LA6_0<='\'')||LA6_0=='*'||(LA6_0>='.' && LA6_0<='/')||LA6_0==';'||(LA6_0>='?' && LA6_0<='}')||(LA6_0>='\u00A1' && LA6_0<='\uFFEE')) ) {
                alt6=1;
            }
            else if ( (LA6_0=='-'||(LA6_0>='0' && LA6_0<='9')) ) {
                alt6=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }
            switch (alt6) {
                case 1 :
                    {
                    int cnt3=0;
                    loop3:
                    do {
                        int alt3=2;
                        int LA3_0 = input.LA(1);

                        if ( (LA3_0=='!'||(LA3_0>='#' && LA3_0<='\'')||LA3_0=='*'||(LA3_0>='.' && LA3_0<='/')||LA3_0==';'||(LA3_0>='?' && LA3_0<='}')||(LA3_0>='\u00A1' && LA3_0<='\uFFEE')) ) {
                            alt3=1;
                        }

                        switch (alt3) {
                    	case 1 :
                    	    {
                    	    mCHAR_SEQ();
                    	    int alt2=2;
                    	    int LA2_0 = input.LA(1);

                    	    if ( (LA2_0=='-'||(LA2_0>='0' && LA2_0<='9')) ) {
                    	        alt2=1;
                    	    }
                    	    switch (alt2) {
                    	        case 1 :
                    	            {
                    	            mNUMBER();

                    	            }
                    	            break;

                    	    }

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt3 >= 1 ) break loop3;
                                EarlyExitException eee =
                                    new EarlyExitException(3, input);
                                throw eee;
                        }
                        cnt3++;
                    } while (true);

                    }
                    break;
                case 2 :
                    {
                    int cnt5=0;
                    loop5:
                    do {
                        int alt5=2;
                        int LA5_0 = input.LA(1);

                        if ( (LA5_0=='-'||(LA5_0>='0' && LA5_0<='9')) ) {
                            alt5=1;
                        }

                        switch (alt5) {
                    	case 1 :
                    	    {
                    	    mNUMBER();
                    	    int alt4=2;
                    	    int LA4_0 = input.LA(1);

                    	    if ( (LA4_0=='!'||(LA4_0>='#' && LA4_0<='\'')||LA4_0=='*'||(LA4_0>='.' && LA4_0<='/')||LA4_0==';'||(LA4_0>='?' && LA4_0<='}')||(LA4_0>='\u00A1' && LA4_0<='\uFFEE')) ) {
                    	        alt4=1;
                    	    }
                    	    switch (alt4) {
                    	        case 1 :
                    	            {
                    	            mCHAR_SEQ();

                    	            }
                    	            break;

                    	    }

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt5 >= 1 ) break loop5;
                                EarlyExitException eee =
                                    new EarlyExitException(5, input);
                                throw eee;
                        }
                        cnt5++;
                    } while (true);

                    }
                    break;

            }
            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }

    public final void mNUMBER() throws RecognitionException {
        try {
            int alt14=2;
            alt14 = dfa14.predict(input);
            switch (alt14) {
                case 1 :
                    {
                    int alt7=2;
                    int LA7_0 = input.LA(1);

                    if ( (LA7_0=='-') ) {
                        alt7=1;
                    }
                    switch (alt7) {
                        case 1 :
                            {
                            match('-');

                            }
                            break;

                    }

                    int cnt8=0;
                    loop8:
                    do {
                        int alt8=2;
                        int LA8_0 = input.LA(1);

                        if ( ((LA8_0>='0' && LA8_0<='9')) ) {
                            alt8=1;
                        }

                        switch (alt8) {
                    	case 1 :
                    	    {
                    	    mDIGIT();

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt8 >= 1 ) break loop8;
                                EarlyExitException eee =
                                    new EarlyExitException(8, input);
                                throw eee;
                        }
                        cnt8++;
                    } while (true);

                    match('.');
                    loop9:
                    do {
                        int alt9=2;
                        int LA9_0 = input.LA(1);

                        if ( ((LA9_0>='0' && LA9_0<='9')) ) {
                            alt9=1;
                        }

                        switch (alt9) {
                    	case 1 :
                    	    {
                    	    mDIGIT();

                    	    }
                    	    break;

                    	default :
                    	    break loop9;
                        }
                    } while (true);

                    int alt10=2;
                    int LA10_0 = input.LA(1);

                    if ( (LA10_0=='E'||LA10_0=='e') ) {
                        alt10=1;
                    }
                    switch (alt10) {
                        case 1 :
                            {
                            mEXPONENT();

                            }
                            break;

                    }

                    }
                    break;
                case 2 :
                    {
                    int alt11=2;
                    int LA11_0 = input.LA(1);

                    if ( (LA11_0=='-') ) {
                        alt11=1;
                    }
                    switch (alt11) {
                        case 1 :
                            {
                            match('-');

                            }
                            break;

                    }

                    int cnt12=0;
                    loop12:
                    do {
                        int alt12=2;
                        int LA12_0 = input.LA(1);

                        if ( ((LA12_0>='0' && LA12_0<='9')) ) {
                            alt12=1;
                        }

                        switch (alt12) {
                    	case 1 :
                    	    {
                    	    mDIGIT();

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt12 >= 1 ) break loop12;
                                EarlyExitException eee =
                                    new EarlyExitException(12, input);
                                throw eee;
                        }
                        cnt12++;
                    } while (true);

                    int alt13=2;
                    int LA13_0 = input.LA(1);

                    if ( (LA13_0=='E'||LA13_0=='e') ) {
                        alt13=1;
                    }
                    switch (alt13) {
                        case 1 :
                            {
                            mEXPONENT();

                            }
                            break;

                    }

                    }
                    break;

            }
        }
        finally {
        }
    }

    public final void mEXPONENT() throws RecognitionException {
        try {
            {
            if ( input.LA(1)=='E'||input.LA(1)=='e' ) {
                input.consume();

            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}

            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0=='+'||LA15_0=='-') ) {
                alt15=1;
            }
            switch (alt15) {
                case 1 :
                    {
                    if ( input.LA(1)=='+'||input.LA(1)=='-' ) {
                        input.consume();

                    }
                    else {
                        MismatchedSetException mse = new MismatchedSetException(null,input);
                        recover(mse);
                        throw mse;}

                    }
                    break;

            }

            int cnt16=0;
            loop16:
            do {
                int alt16=2;
                int LA16_0 = input.LA(1);

                if ( ((LA16_0>='0' && LA16_0<='9')) ) {
                    alt16=1;
                }

                switch (alt16) {
            	case 1 :
            	    {
            	    mDIGIT();

            	    }
            	    break;

            	default :
            	    if ( cnt16 >= 1 ) break loop16;
                        EarlyExitException eee =
                            new EarlyExitException(16, input);
                        throw eee;
                }
                cnt16++;
            } while (true);

            }

        }
        finally {
        }
    }

    public final void mCHAR_SEQ() throws RecognitionException {
        try {
            {
            int alt17=4;
            int LA17_0 = input.LA(1);

            if ( (LA17_0=='!'||(LA17_0>='#' && LA17_0<='\'')||LA17_0=='*'||(LA17_0>='.' && LA17_0<='/')||LA17_0==';'||(LA17_0>='?' && LA17_0<='[')||(LA17_0>=']' && LA17_0<='}')||(LA17_0>='\u00A1' && LA17_0<='\uFFEE')) ) {
                alt17=1;
            }
            else if ( (LA17_0=='\\') ) {
                switch ( input.LA(2) ) {
                case '\"':
                case '+':
                case ',':
                case ':':
                case '<':
                case '=':
                case '>':
                case '\\':
                case '~':
                    {
                    alt17=2;
                    }
                    break;
                case 'u':
                    {
                    alt17=3;
                    }
                    break;
                case '0':
                case '1':
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                    {
                    alt17=4;
                    }
                    break;
                default:
                    NoViableAltException nvae =
                        new NoViableAltException("", 17, 2, input);

                    throw nvae;
                }

            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 17, 0, input);

                throw nvae;
            }
            switch (alt17) {
                case 1 :
                    {
                    mSTART_CHAR();

                    }
                    break;
                case 2 :
                    {
                    mESCAPED_CHAR();

                    }
                    break;
                case 3 :
                    {
                    mUNICODE_ESC();

                    }
                    break;
                case 4 :
                    {
                    mOCTAL_ESC();

                    }
                    break;

            }

            loop18:
            do {
                int alt18=5;
                int LA18_0 = input.LA(1);

                if ( (LA18_0=='!'||(LA18_0>='#' && LA18_0<='\'')||(LA18_0>='*' && LA18_0<='+')||(LA18_0>='-' && LA18_0<='9')||LA18_0==';'||(LA18_0>='?' && LA18_0<='[')||(LA18_0>=']' && LA18_0<='}')||(LA18_0>='\u00A1' && LA18_0<='\uFFEE')) ) {
                    alt18=1;
                }
                else if ( (LA18_0=='\\') ) {
                    switch ( input.LA(2) ) {
                    case '\"':
                    case '+':
                    case ',':
                    case ':':
                    case '<':
                    case '=':
                    case '>':
                    case '\\':
                    case '~':
                        {
                        alt18=2;
                        }
                        break;
                    case 'u':
                        {
                        alt18=3;
                        }
                        break;
                    case '0':
                    case '1':
                    case '2':
                    case '3':
                    case '4':
                    case '5':
                    case '6':
                    case '7':
                        {
                        alt18=4;
                        }
                        break;

                    }

                }

                switch (alt18) {
            	case 1 :
            	    {
            	    mMID_CHAR();

            	    }
            	    break;
            	case 2 :
            	    {
            	    mESCAPED_CHAR();

            	    }
            	    break;
            	case 3 :
            	    {
            	    mUNICODE_ESC();

            	    }
            	    break;
            	case 4 :
            	    {
            	    mOCTAL_ESC();

            	    }
            	    break;

            	default :
            	    break loop18;
                }
            } while (true);

            }

        }
        finally {
        }
    }

    public final void mUNICODE_ESC() throws RecognitionException {
        try {
            {
            match('\\');
            match('u');
            mHEX_DIGIT();
            mHEX_DIGIT();
            mHEX_DIGIT();
            mHEX_DIGIT();

            }

        }
        finally {
        }
    }

    public final void mOCTAL_ESC() throws RecognitionException {
        try {
            int alt19=3;
            int LA19_0 = input.LA(1);

            if ( (LA19_0=='\\') ) {
                int LA19_1 = input.LA(2);

                if ( ((LA19_1>='0' && LA19_1<='3')) ) {
                    int LA19_2 = input.LA(3);

                    if ( ((LA19_2>='0' && LA19_2<='7')) ) {
                        int LA19_4 = input.LA(4);

                        if ( ((LA19_4>='0' && LA19_4<='7')) ) {
                            alt19=1;
                        }
                        else {
                            alt19=2;}
                    }
                    else {
                        alt19=3;}
                }
                else if ( ((LA19_1>='4' && LA19_1<='7')) ) {
                    int LA19_3 = input.LA(3);

                    if ( ((LA19_3>='0' && LA19_3<='7')) ) {
                        alt19=2;
                    }
                    else {
                        alt19=3;}
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 19, 1, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 19, 0, input);

                throw nvae;
            }
            switch (alt19) {
                case 1 :
                    {
                    match('\\');
                    {
                    matchRange('0','3');

                    }

                    {
                    matchRange('0','7');

                    }

                    {
                    matchRange('0','7');

                    }

                    }
                    break;
                case 2 :
                    {
                    match('\\');
                    {
                    matchRange('0','7');

                    }

                    {
                    matchRange('0','7');

                    }

                    }
                    break;
                case 3 :
                    {
                    match('\\');
                    {
                    matchRange('0','7');

                    }

                    }
                    break;

            }
        }
        finally {
        }
    }

    public final void mDIGIT() throws RecognitionException {
        try {
            {
            matchRange('0','9');

            }

        }
        finally {
        }
    }

    public final void mHEX_DIGIT() throws RecognitionException {
        try {
            {
            if ( (input.LA(1)>='0' && input.LA(1)<='9')||(input.LA(1)>='A' && input.LA(1)<='F')||(input.LA(1)>='a' && input.LA(1)<='f') ) {
                input.consume();

            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}

            }

        }
        finally {
        }
    }

    public final void mSTART_CHAR() throws RecognitionException {
        try {
            {
            if ( input.LA(1)=='!'||(input.LA(1)>='#' && input.LA(1)<='\'')||input.LA(1)=='*'||(input.LA(1)>='.' && input.LA(1)<='/')||input.LA(1)==';'||(input.LA(1)>='?' && input.LA(1)<='[')||(input.LA(1)>=']' && input.LA(1)<='}')||(input.LA(1)>='\u00A1' && input.LA(1)<='\uFFEE') ) {
                input.consume();

            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}

            }

        }
        finally {
        }
    }

    public final void mMID_CHAR() throws RecognitionException {
        try {
            {
            if ( input.LA(1)=='!'||(input.LA(1)>='#' && input.LA(1)<='\'')||(input.LA(1)>='*' && input.LA(1)<='+')||(input.LA(1)>='-' && input.LA(1)<='9')||input.LA(1)==';'||(input.LA(1)>='?' && input.LA(1)<='[')||(input.LA(1)>=']' && input.LA(1)<='}')||(input.LA(1)>='\u00A1' && input.LA(1)<='\uFFEE') ) {
                input.consume();

            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}

            }

        }
        finally {
        }
    }

    public final void mESCAPED_CHAR() throws RecognitionException {
        try {
            int alt20=9;
            alt20 = dfa20.predict(input);
            switch (alt20) {
                case 1 :
                    {
                    match("\\,");

                    }
                    break;
                case 2 :
                    {
                    match("\\:");

                    }
                    break;
                case 3 :
                    {
                    match("\\=");

                    }
                    break;
                case 4 :
                    {
                    match("\\<");

                    }
                    break;
                case 5 :
                    {
                    match("\\>");

                    }
                    break;
                case 6 :
                    {
                    match("\\+");

                    }
                    break;
                case 7 :
                    {
                    match("\\~");

                    }
                    break;
                case 8 :
                    {
                    match("\\\"");

                    }
                    break;
                case 9 :
                    {
                    match("\\\\");

                    }
                    break;

            }
        }
        finally {
        }
    }

    public void mTokens() throws RecognitionException {
        int alt21=23;
        alt21 = dfa21.predict(input);
        switch (alt21) {
            case 1 :
                {
                mT__45();

                }
                break;
            case 2 :
                {
                mT__46();

                }
                break;
            case 3 :
                {
                mT__47();

                }
                break;
            case 4 :
                {
                mHAS();

                }
                break;
            case 5 :
                {
                mOR();

                }
                break;
            case 6 :
                {
                mAND();

                }
                break;
            case 7 :
                {
                mNOT();

                }
                break;
            case 8 :
                {
                mREWRITE();

                }
                break;
            case 9 :
                {
                mFIX();

                }
                break;
            case 10 :
                {
                mDISTANCE_FN();

                }
                break;
            case 11 :
                {
                mGEO_POINT_FN();

                }
                break;
            case 12 :
                {
                mESC();

                }
                break;
            case 13 :
                {
                mWS();

                }
                break;
            case 14 :
                {
                mLPAREN();

                }
                break;
            case 15 :
                {
                mRPAREN();

                }
                break;
            case 16 :
                {
                mLT();

                }
                break;
            case 17 :
                {
                mGT();

                }
                break;
            case 18 :
                {
                mGE();

                }
                break;
            case 19 :
                {
                mLE();

                }
                break;
            case 20 :
                {
                mNE();

                }
                break;
            case 21 :
                {
                mEQ();

                }
                break;
            case 22 :
                {
                mQUOTE();

                }
                break;
            case 23 :
                {
                mTEXT();

                }
                break;

        }

    }

    protected DFA14 dfa14 = new DFA14(this);
    protected DFA20 dfa20 = new DFA20(this);
    protected DFA21 dfa21 = new DFA21(this);
    static final String DFA14_eotS =
        "\2\uffff\1\3\2\uffff";
    static final String DFA14_eofS =
        "\5\uffff";
    static final String DFA14_minS =
        "\1\55\1\60\1\56\2\uffff";
    static final String DFA14_maxS =
        "\3\71\2\uffff";
    static final String DFA14_acceptS =
        "\3\uffff\1\2\1\1";
    static final String DFA14_specialS =
        "\5\uffff}>";
    static final String[] DFA14_transitionS = {
            "\1\1\2\uffff\12\2",
            "\12\2",
            "\1\4\1\uffff\12\2",
            "",
            ""
    };

    static final short[] DFA14_eot = DFA.unpackEncodedString(DFA14_eotS);
    static final short[] DFA14_eof = DFA.unpackEncodedString(DFA14_eofS);
    static final char[] DFA14_min = DFA.unpackEncodedStringToUnsignedChars(DFA14_minS);
    static final char[] DFA14_max = DFA.unpackEncodedStringToUnsignedChars(DFA14_maxS);
    static final short[] DFA14_accept = DFA.unpackEncodedString(DFA14_acceptS);
    static final short[] DFA14_special = DFA.unpackEncodedString(DFA14_specialS);
    static final short[][] DFA14_transition;

    static {
        int numStates = DFA14_transitionS.length;
        DFA14_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA14_transition[i] = DFA.unpackEncodedString(DFA14_transitionS[i]);
        }
    }

    class DFA14 extends DFA {

        public DFA14(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 14;
            this.eot = DFA14_eot;
            this.eof = DFA14_eof;
            this.min = DFA14_min;
            this.max = DFA14_max;
            this.accept = DFA14_accept;
            this.special = DFA14_special;
            this.transition = DFA14_transition;
        }
        public String getDescription() {
            return "265:10: fragment NUMBER : ( ( '-' )? ( DIGIT )+ '.' ( DIGIT )* ( EXPONENT )? | ( '-' )? ( DIGIT )+ ( EXPONENT )? );";
        }
    }
    static final String DFA20_eotS =
        "\13\uffff";
    static final String DFA20_eofS =
        "\13\uffff";
    static final String DFA20_minS =
        "\1\134\1\42\11\uffff";
    static final String DFA20_maxS =
        "\1\134\1\176\11\uffff";
    static final String DFA20_acceptS =
        "\2\uffff\1\1\1\2\1\3\1\4\1\5\1\6\1\7\1\10\1\11";
    static final String DFA20_specialS =
        "\13\uffff}>";
    static final String[] DFA20_transitionS = {
            "\1\1",
            "\1\11\10\uffff\1\7\1\2\15\uffff\1\3\1\uffff\1\5\1\4\1\6\35"+
            "\uffff\1\12\41\uffff\1\10",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA20_eot = DFA.unpackEncodedString(DFA20_eotS);
    static final short[] DFA20_eof = DFA.unpackEncodedString(DFA20_eofS);
    static final char[] DFA20_min = DFA.unpackEncodedStringToUnsignedChars(DFA20_minS);
    static final char[] DFA20_max = DFA.unpackEncodedStringToUnsignedChars(DFA20_maxS);
    static final short[] DFA20_accept = DFA.unpackEncodedString(DFA20_acceptS);
    static final short[] DFA20_special = DFA.unpackEncodedString(DFA20_specialS);
    static final short[][] DFA20_transition;

    static {
        int numStates = DFA20_transitionS.length;
        DFA20_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA20_transition[i] = DFA.unpackEncodedString(DFA20_transitionS[i]);
        }
    }

    class DFA20 extends DFA {

        public DFA20(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 20;
            this.eot = DFA20_eot;
            this.eof = DFA20_eof;
            this.min = DFA20_min;
            this.max = DFA20_max;
            this.accept = DFA20_accept;
            this.special = DFA20_special;
            this.transition = DFA20_transition;
        }
        public String getDescription() {
            return "332:10: fragment ESCAPED_CHAR : ( '\\\\,' | '\\\\:' | '\\\\=' | '\\\\<' | '\\\\>' | '\\\\+' | '\\\\~' | '\\\\\"' | '\\\\\\\\' );";
        }
    }
    static final String DFA21_eotS =
        "\1\uffff\1\25\1\uffff\1\31\1\uffff\3\24\2\uffff\2\24\3\uffff\1\42"+
        "\1\44\1\24\4\uffff\1\46\1\uffff\1\46\1\uffff\2\46\1\52\4\24\7\uffff"+
        "\2\46\1\uffff\1\61\1\62\2\24\1\uffff\1\46\2\uffff\2\24\1\uffff\2"+
        "\24\1\46\4\24\1\77\1\100\2\uffff";
    static final String DFA21_eofS =
        "\101\uffff";
    static final String DFA21_minS =
        "\1\11\1\60\1\uffff\1\42\1\uffff\1\122\1\116\1\117\2\uffff\1\151"+
        "\1\145\3\uffff\3\75\4\uffff\1\41\1\60\1\41\1\uffff\3\41\1\104\1"+
        "\124\1\163\1\157\6\uffff\1\60\2\41\1\uffff\2\41\1\164\1\160\1\60"+
        "\1\41\2\uffff\1\141\1\157\1\60\1\156\1\151\1\41\1\143\1\156\1\145"+
        "\1\164\2\41\2\uffff";
    static final String DFA21_maxS =
        "\1\uffee\1\71\1\uffff\1\176\1\uffff\1\122\1\116\1\117\2\uffff\1"+
        "\151\1\145\3\uffff\3\75\4\uffff\1\uffee\1\146\1\uffee\1\uffff\3"+
        "\uffee\1\104\1\124\1\163\1\157\6\uffff\1\146\2\uffee\1\uffff\2\uffee"+
        "\1\164\1\160\1\146\1\uffee\2\uffff\1\141\1\157\1\146\1\156\1\151"+
        "\1\uffee\1\143\1\156\1\145\1\164\2\uffee\2\uffff";
    static final String DFA21_acceptS =
        "\2\uffff\1\2\1\uffff\1\4\3\uffff\1\10\1\11\2\uffff\1\15\1\16\1\17"+
        "\3\uffff\1\25\1\26\1\27\1\1\3\uffff\1\3\7\uffff\1\23\1\20\1\22\1"+
        "\21\1\24\1\14\3\uffff\1\5\6\uffff\1\6\1\7\14\uffff\1\12\1\13";
    static final String DFA21_specialS =
        "\101\uffff}>";
    static final String[] DFA21_transitionS = {
            "\2\14\1\uffff\2\14\22\uffff\1\14\1\21\1\23\5\24\1\15\1\16\1"+
            "\24\1\11\1\2\1\1\14\24\1\4\1\24\1\17\1\22\1\20\2\24\1\6\14\24"+
            "\1\7\1\5\14\24\1\3\7\24\1\12\2\24\1\13\26\24\1\10\42\uffff\uff4e"+
            "\24",
            "\12\24",
            "",
            "\1\26\10\uffff\2\24\3\uffff\4\32\4\33\2\uffff\1\24\1\uffff"+
            "\3\24\35\uffff\1\30\30\uffff\1\27\10\uffff\1\24",
            "",
            "\1\34",
            "\1\35",
            "\1\36",
            "",
            "",
            "\1\37",
            "\1\40",
            "",
            "",
            "",
            "\1\41",
            "\1\43",
            "\1\45",
            "",
            "",
            "",
            "",
            "\1\24\1\uffff\5\24\2\uffff\2\24\1\uffff\15\24\1\uffff\1\24"+
            "\3\uffff\77\24\43\uffff\uff4e\24",
            "\12\47\7\uffff\6\47\32\uffff\6\47",
            "\1\24\1\uffff\5\24\2\uffff\2\24\1\uffff\15\24\1\uffff\1\24"+
            "\3\uffff\77\24\43\uffff\uff4e\24",
            "",
            "\1\24\1\uffff\5\24\2\uffff\2\24\1\uffff\3\24\10\50\2\24\1\uffff"+
            "\1\24\3\uffff\77\24\43\uffff\uff4e\24",
            "\1\24\1\uffff\5\24\2\uffff\2\24\1\uffff\3\24\10\51\2\24\1\uffff"+
            "\1\24\3\uffff\77\24\43\uffff\uff4e\24",
            "\1\24\1\uffff\5\24\2\uffff\2\24\1\uffff\15\24\1\uffff\1\24"+
            "\3\uffff\77\24\43\uffff\uff4e\24",
            "\1\53",
            "\1\54",
            "\1\55",
            "\1\56",
            "",
            "",
            "",
            "",
            "",
            "",
            "\12\57\7\uffff\6\57\32\uffff\6\57",
            "\1\24\1\uffff\5\24\2\uffff\2\24\1\uffff\3\24\10\60\2\24\1\uffff"+
            "\1\24\3\uffff\77\24\43\uffff\uff4e\24",
            "\1\24\1\uffff\5\24\2\uffff\2\24\1\uffff\15\24\1\uffff\1\24"+
            "\3\uffff\77\24\43\uffff\uff4e\24",
            "",
            "\1\24\1\uffff\5\24\2\uffff\2\24\1\uffff\15\24\1\uffff\1\24"+
            "\3\uffff\77\24\43\uffff\uff4e\24",
            "\1\24\1\uffff\5\24\2\uffff\2\24\1\uffff\15\24\1\uffff\1\24"+
            "\3\uffff\77\24\43\uffff\uff4e\24",
            "\1\63",
            "\1\64",
            "\12\65\7\uffff\6\65\32\uffff\6\65",
            "\1\24\1\uffff\5\24\2\uffff\2\24\1\uffff\15\24\1\uffff\1\24"+
            "\3\uffff\77\24\43\uffff\uff4e\24",
            "",
            "",
            "\1\66",
            "\1\67",
            "\12\70\7\uffff\6\70\32\uffff\6\70",
            "\1\71",
            "\1\72",
            "\1\24\1\uffff\5\24\2\uffff\2\24\1\uffff\15\24\1\uffff\1\24"+
            "\3\uffff\77\24\43\uffff\uff4e\24",
            "\1\73",
            "\1\74",
            "\1\75",
            "\1\76",
            "\1\24\1\uffff\5\24\2\uffff\2\24\1\uffff\15\24\1\uffff\1\24"+
            "\3\uffff\77\24\43\uffff\uff4e\24",
            "\1\24\1\uffff\5\24\2\uffff\2\24\1\uffff\15\24\1\uffff\1\24"+
            "\3\uffff\77\24\43\uffff\uff4e\24",
            "",
            ""
    };

    static final short[] DFA21_eot = DFA.unpackEncodedString(DFA21_eotS);
    static final short[] DFA21_eof = DFA.unpackEncodedString(DFA21_eofS);
    static final char[] DFA21_min = DFA.unpackEncodedStringToUnsignedChars(DFA21_minS);
    static final char[] DFA21_max = DFA.unpackEncodedStringToUnsignedChars(DFA21_maxS);
    static final short[] DFA21_accept = DFA.unpackEncodedString(DFA21_acceptS);
    static final short[] DFA21_special = DFA.unpackEncodedString(DFA21_specialS);
    static final short[][] DFA21_transition;

    static {
        int numStates = DFA21_transitionS.length;
        DFA21_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA21_transition[i] = DFA.unpackEncodedString(DFA21_transitionS[i]);
        }
    }

    class DFA21 extends DFA {

        public DFA21(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 21;
            this.eot = DFA21_eot;
            this.eof = DFA21_eof;
            this.min = DFA21_min;
            this.max = DFA21_max;
            this.accept = DFA21_accept;
            this.special = DFA21_special;
            this.transition = DFA21_transition;
        }
        public String getDescription() {
            return "1:1: Tokens : ( T__45 | T__46 | T__47 | HAS | OR | AND | NOT | REWRITE | FIX | DISTANCE_FN | GEO_POINT_FN | ESC | WS | LPAREN | RPAREN | LT | GT | GE | LE | NE | EQ | QUOTE | TEXT );";
        }
    }

}
