// Copyright 2011 Google Inc. All Rights Reserved.

package com.google.appengine.api.search.checkers;

import com.google.appengine.api.search.SearchServicePb.ScorerSpec;

/**
 * Checks the values of a {@link SortOptions}.
 *
 */
public class SortOptionsChecker {

  /**
   * The maximum number of documents that can be requested to be scored.
   */
  public static final int MAXIMUM_LIMIT = 10000;

  /**
   * The default number of documents to score.
   */
  public static final int DEFAULT_LIMIT = 1000;

  /**
   * Checks whether the limit on number of documents to score is between 0 and
   * the maximum.
   *
   * @param limit the maximum number of documents to score in the search
   * @return the checked limit
   * @throws IllegalArgumentException if the limit is out of range
   */
  public static int checkLimit(int limit) {
    Preconditions.checkArgument(limit >= 0 && limit <= MAXIMUM_LIMIT,
        "The limit %d must be between 0 and %d", limit, MAXIMUM_LIMIT);
    return limit;
  }

  /**
   * Checks the {@link ScorerSpec} is valid, specifically checking the limit
   * on number of documents to score is not too large.
   *
   * @param spec the {@link ScorerSpec} to check
   * @return the checked spec
   * @throws IllegalArgumentException if the spec is invalid
   */
  public static ScorerSpec checkValid(ScorerSpec spec) {
    checkLimit(spec.getLimit());
    return spec;
  }
}
