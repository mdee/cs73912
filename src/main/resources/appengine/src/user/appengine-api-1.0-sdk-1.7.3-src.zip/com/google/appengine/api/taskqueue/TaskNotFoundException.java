// Copyright 2011 Google Inc. All Rights Reserved.
package com.google.appengine.api.taskqueue;

/**
 * The task does not exist in the queue.
 *
 */
class TaskNotFoundException extends RuntimeException {
  public TaskNotFoundException(String detail) {
    super(detail);
  }
}
