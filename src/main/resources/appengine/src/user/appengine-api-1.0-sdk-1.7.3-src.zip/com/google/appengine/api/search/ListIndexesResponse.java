// Copyright 2011 Google Inc. All Rights Reserved.

package com.google.appengine.api.search;

import com.google.appengine.api.search.checkers.Preconditions;

import java.io.Serializable;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * Represents a result of executing a {@link ListIndexesRequest}. The response
 * contains a list of {@link Index} that the application has access to.
 *
 * @deprecated as of 1.7.3. Use {@link GetResponse} instead
 */
@Deprecated
public class ListIndexesResponse implements Iterable<Index>, Serializable {
  private static final long serialVersionUID = 1189234703739911898L;

  private final List<Index> indexes;

  /**
   * Creates a {@link ListIndexesResponse} by specifying a list of
   * {@link Index} that an application has access to.
   *
   * @param indexes a list of {@link Index} that an application has access to
   */
  protected ListIndexesResponse(List<Index> indexes) {
    this.indexes = Collections.unmodifiableList(
        Preconditions.checkNotNull(indexes, "indexes cannot be null"));
  }

  @Override
  public Iterator<Index> iterator() {
    return indexes.iterator();
  }

  /**
   * @return an unmodifiable list of {@link Index} that an application has
   * access to
   */
  public List<Index> getIndexes() {
    return indexes;
  }

  @Override
  public String toString() {
    return String.format("ListIndexesResponse(indexes=%s)", Util.iterableToString(indexes, 0));
  }
}
