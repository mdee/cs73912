// Copyright 2011 Google Inc. All Rights Reserved.

package com.google.appengine.api.search;

import com.google.appengine.api.search.checkers.IndexChecker;

/**
 * Represents information about an index. This class is used to fully specify
 * the index you want to retrieve from the {@link SearchService}.
 * To build an instance use the {@link #newBuilder()} method and set
 * all required parameters, plus optional values different than the defaults.
 * <pre>
 *   SearchService searchService = SearchServiceFactory.getSearchService();
 *
 *   IndexSpec spec = IndexSpec.newBuilder()
 *       .setName("docs")
 *       .build();
 *
 *   Index index = searchService.getIndex(spec);
 * </pre>
 *
 */
public class IndexSpec {

  /**
   * A builder of IndexSpec.
   */
  public static final class Builder {
    private String name;
    private Consistency consistency;

    /**
     * Constructs a builder for an IndexSpec.
     */
    private Builder() {
    }

    /**
     * Sets the unique name of the index.
     *
     * @param name the name of the index
     * @return this Builder
     * @throws IllegalArgumentException if the index name length is not between 1
     * and {@literal IndexChecker#MAXIMUM_INDEX_NAME_LENGTH}
     */
    public Builder setName(String name) {
      this.name = IndexChecker.checkName(name);
      return this;
    }

    /**
     * Sets the consistency mode in which the index operates.
     *
     * @param consistency the consistency mode in which the index operates
     * @return this Builder
     *
     * @deprecated As of 1.7.3, consistency setting is no longer required,
     *   since PER_DOCUMENT is the only mode supported.
     */
    @Deprecated
    public Builder setConsistency(Consistency consistency) {
      this.consistency = consistency;
      return this;
    }

    /**
     * Builds a valid IndexSpec. The builder must have set a valid
     * index name.
     *
     * @return the IndexSpec built by this builder
     * @throws IllegalArgumentException if the IndexSpec built is not valid
     */
    public IndexSpec build() {
      return new IndexSpec(this);
    }
  }

  private final String name;
  private final Consistency consistency;

  /**
   * Creates new index specification.
   *
   * @param builder the IndexSpec builder to use to construct an instance
   * @throws IllegalArgumentException if the index name is invalid
   */
  private IndexSpec(Builder builder) {
    consistency = Util.defaultIfNull(builder.consistency, Consistency.PER_DOCUMENT);
    name = builder.name;
  }

  /**
   * @return the name of the index
   */
  public String getName() {
    return name;
  }

  /**
   * @return the consistency mode of this index
   *
   * @deprececated As of 1.7.3, setting consistency modes no longer supported.
   */
  @Deprecated
  public Consistency getConsistency() {
    return consistency;
  }

  /**
   * Creates a new IndexSpec builder. You must use this method to obtain a new
   * builder. The returned builder must be used to specify all properties of
   * the IndexSpec. To obtain the IndexSpec call the {@link Builder#build()}
   * method on the returned builder.
   *
   * @return a builder which constructs a IndexSpec object
   */
  public static Builder newBuilder() {
    return new Builder();
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((consistency == null) ? 0 : consistency.hashCode());
    result = prime * result + ((name == null) ? 0 : name.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj) {
      return true;
    }
    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    IndexSpec other = (IndexSpec) obj;
    if (consistency == null) {
      if (other.consistency != null) {
        return false;
      }
    } else if (!consistency.equals(other.consistency)) {
      return false;
    }
    if (name == null) {
      if (other.name != null) {
        return false;
      }
    } else if (!name.equals(other.name)) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return String.format("IndexSpec{name: %s, consistency: %s}", name, consistency.name());
  }

  /**
   * Creates an SearchServicePb.IndexSpec from the given Index.
   *
   * @param namespace the namespace for the index
   * @return a valid SearchServicePb.IndexSpec.Builder
   * @throws IllegalArgumentException if the consistency is not a known type
   */
  SearchServicePb.IndexSpec.Builder copyToProtocolBuffer(String namespace) {
      SearchServicePb.IndexSpec.Builder builder = SearchServicePb.IndexSpec.newBuilder()
        .setName(getName())
        .setNamespace(namespace);

    switch (getConsistency().getConsistency()) {
      case GLOBAL:
        builder.setConsistency(SearchServicePb.IndexSpec.Consistency.GLOBAL);
        break;
      case PER_DOCUMENT:
        builder.setConsistency(SearchServicePb.IndexSpec.Consistency.PER_DOCUMENT);
        break;
      default:
        throw new IllegalArgumentException(String.format("unknown consistency type %s",
            getConsistency().getConsistency().name()));
    }
    return builder;
  }
}
